QA_Launcher 사용 안내
====================================

[1] 바이러스로 삭제된다면 (Windows Defender 오탐)
    QA_Launcher.exe 는 서명되지 않은 소형 실행파일이라 Defender가
    오탐으로 삭제할 수 있습니다. 아래 순서로 예외 등록하세요.

    1. QA_Launcher_AllowInDefender.bat 우클릭 -> "관리자 권한으로 실행"
    2. UAC 창에서 "예"
       -> 이 폴더/다운로드/바탕화면을 Defender 예외로 등록하고
          격리된 파일을 복원합니다.
    3. 그다음 QA_Launcher.exe 실행

[2] "Windows가 PC를 보호했습니다" 창이 뜨면
    추가 정보 -> 실행 을 누르면 실행됩니다.

[3] 런처 설명
    - GitHub에서 최신 클라이언트 빌드를 받아 실행합니다.
    - 런처 자신도 자동 업데이트됩니다.
    - ApiPhase 기본값은 reviews 입니다.

문의는 배포 담당자에게.
