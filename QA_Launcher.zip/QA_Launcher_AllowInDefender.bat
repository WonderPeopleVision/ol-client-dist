@echo off
title QA_Launcher - Defender 예외 등록
chcp 65001 >nul
REM 관리자 권한이 아니면 UAC로 재실행
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo 관리자 권한이 필요합니다. UAC 창에서 "예"를 눌러주세요...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ============================================================
echo  QA_Launcher Windows Defender 예외 등록 (관리자)
echo ============================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0QA_Launcher_AllowInDefender.ps1"
echo.
pause
