# ================================================================
# QA_Launcher - Windows Defender 예외 등록 + 격리 복원
# (QA_Launcher_AllowInDefender.bat 로 실행하면 관리자 권한 자동 승격)
#
# QA_Launcher.exe 는 서명되지 않은 소형 .NET 실행파일이라 Windows Defender가
# 오탐(Trojan:Win32/Bearfoos.A!ml 등)으로 삭제할 수 있습니다. 이 스크립트가
# 실행 폴더/다운로드/바탕화면을 예외로 등록하고, 격리된 파일을 복원합니다.
# ================================================================
$ErrorActionPreference = 'SilentlyContinue'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

$paths = @(
    $scriptDir,
    (Join-Path $env:USERPROFILE 'Desktop'),
    (Join-Path $env:USERPROFILE 'Downloads')
)
$paths = $paths | ForEach-Object { $_.TrimEnd('\') } |
         Where-Object { $_ } | Select-Object -Unique

Write-Host '=== Defender 경로 예외 등록 ===' -ForegroundColor Cyan
foreach ($p in $paths) {
    if (Test-Path $p) { Add-MpPreference -ExclusionPath $p; Write-Host "  [+] path: $p" }
}

Write-Host '=== 프로세스 예외 등록 ===' -ForegroundColor Cyan
foreach ($n in 'QA_Launcher.exe','ProjectOLClient.exe','7za.exe') {
    Add-MpPreference -ExclusionProcess $n; Write-Host "  [+] process: $n"
}

Write-Host '=== 격리된 파일 복원 시도 ===' -ForegroundColor Cyan
$mp = "$env:ProgramFiles\Windows Defender\MpCmdRun.exe"
if (Test-Path $mp) {
    & $mp -Restore -Name 'Trojan:Win32/Bearfoos.A!ml' 2>&1 | Out-Host
    & $mp -Restore -All 2>&1 | Out-Host
}

Write-Host ''
Write-Host '=== 현재 예외 목록 ===' -ForegroundColor Cyan
Write-Host '[ExclusionPath]';    (Get-MpPreference).ExclusionPath
Write-Host '[ExclusionProcess]'; (Get-MpPreference).ExclusionProcess

Write-Host ''
Write-Host '완료되었습니다. 이제 QA_Launcher.exe 를 실행하세요.' -ForegroundColor Green
